module.exports = {
  output: 'export',
  trailingSlash: true
}

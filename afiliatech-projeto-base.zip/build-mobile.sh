#!/bin/bash
npm run build
npx next export
npx cap copy android

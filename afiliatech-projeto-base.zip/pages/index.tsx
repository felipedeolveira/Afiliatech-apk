export default function Home() {
  return (
    <div style={{ textAlign: 'center', paddingTop: 100 }}>
      <h1>AfiliaTech</h1>
      <h2>Bem-vindo ao AfiliaTech</h2>
      <p>Seu aplicativo de afiliados</p>
    </div>
  );
}
